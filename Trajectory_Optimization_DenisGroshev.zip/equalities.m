function equalities = equalities(x)
global beta_phase iPhase t_phase
global m_structure; m_structure = [2717,544];
global m_fuel; m_fuel = [39463,4037];
global m_payload;
global orbit_R;
    m_payload = x(1)*1000;
    t_phase = [0,10,20,30,50,75,100,140,175,191.34,193,195,220,260,310,350,390,420,490,560,605];
    beta_phase = [90,90,89.973,89.898,84.76,71.349,56.021,38.934,30.622,37.74,37.74,37.74, 90.*x(2:10)];
    global lat;
    %% Assign initial values
    m0 = m_payload+m_structure(1)+m_structure(2)+m_fuel(1)+m_fuel(2);
    x_cord_0 = 6378*cosd(lat); % in spherical coordinates, lat = 90 - lat, negative for south
    y_cord_0 = 0;
    z_cord_0 = 6378*sind(lat);
    dx_0 = 0; 
    tout = [];
    dy_0 = 0.465101*cosd(lat); % Rotation speed at specific latitude, (+) for CCW
    %% Phase #0~9 0~191.34
    y0 = [x_cord_0, y_cord_0, z_cord_0, dx_0, dy_0, 0, m0];
    yout = [];
    n_phase = length(t_phase);
    for iPhase = 2:n_phase
        ti = t_phase(iPhase-1);
        tf = t_phase(iPhase);
        [TT,YY] = ode45(@force_f_opt, ti:tf, y0);
        tout = [tout; TT(end,:)];
        yout = [yout; YY(end,:)];
        y0 = YY(end,:);
        if iPhase == 10
            y0(7) = m_payload+m_structure(2)+m_fuel(2);
        end 
    end
    %% Initializing output for graph
    final = yout(end,:); r0 = [final(1), final(2), final(3)]; v0 = [final(4), final(5), final(6)];
    energy = norm(v0)^2/2-398600/norm(r0); % energy of system
 %   a = -398600/(2*energy); H = cross(r0, v0) ;e = norm(cross(v0,H)/398600-r0/norm(r0));
 %   apogee = a*(1+e); perigee = a*(1-e); 
    v_target = sqrt(398600/(6378+orbit_R));
    equalities(1) = norm(r0)-(orbit_R+6378);
    equalities(2) = norm(v0)-v_target; 
    equalities(3) = dot(r0,v0);
 %   equalities(3) = apogee-perigee;
end