function dydt = force_f(t, yy)
global lat; global i; global beta_list; global orbit_R
global task; global beta_phase
%% Condiitonal changes
x = yy(1); %x-cord
y = yy(2); %y-cord
z = yy(3); %z-cord
dx = yy(4); %x-velocity
dy = yy(5); %y-velocity
dz = yy(6); %z-velocity
m = yy(7); %mass
azimuth = asind(cosd(i)/cosd(lat)); % azimuth in inertial frame with no rotation
%% Cosmodrome to inclination orbit:
mu = 398600;
veq_rot = 2*pi*6378/86164.09; % rotation of Earth on equator
v_orbit = sqrt(mu/orbit_R); % speed at destination orbit
vxrot = v_orbit*sind(azimuth)-veq_rot*cosd(lat); % orbital speed with respect to rotation
vzrot = v_orbit*cosd(azimuth);
azimuth_rot = atand(vxrot/vzrot); % azimuth with relation to Earth rotation
%% Calculating area
if t<193  
    S = 3.14;
else
    S = 1;
end
[p, rho, C_d, gx, gy, gz] = atmosgrav(x,y,z, dx,dy,dz, lat);
%% Calculating angles
t_phase = [0,10,20,30,50,75,100,140,175,191.34,193,195,220,260,310,350,390,420,490,560,605];
if task == 2 
    beta_phase = beta_list;
else
    beta_phase = [90,90,89.973,89.898,84.76,71.349,56.021,38.934,30.622,37.74,37.74,37.74,31.095,26.718,19.356,13.096,6.49,0.758,-10.614,-27.413,-27.413];
end
beta = interp1(t_phase, beta_phase, t); % linear interpolation
%% Calculating acceleartion components
%% Drag
if sqrt(x^2+y^2+z^2)-6378 < 86 % If below edge of atmosphere, drag exists
    a_drag_x = -0.5*rho*dx*sqrt(dx^2+dy^2+dz^2)*S*C_d/(1000*m); % divide by 1000 for km/s^2
    a_drag_y = -0.5*rho*dy*sqrt(dx^2+dy^2+dz^2)*S*C_d/(1000*m);
    a_drag_z = -0.5*rho*dz*sqrt(dx^2+dy^2+dz^2)*S*C_d/(1000*m);
else
    a_drag_x = 0;
    a_drag_y = 0;    
    a_drag_z = 0;
end
%% Thrust
T = [62.5, 3.2];
T_newton = 9806.65.*T;
A_e = [0.9,0.2];
if t<191.34 % if first stage
    a_thrust_x = (T_newton(1)-A_e(1)*p)*sind(beta)*sind(azimuth_rot)/(1000*m);
    a_thrust_y = (T_newton(1)-A_e(1)*p)*cosd(beta)*sind(azimuth_rot)/(1000*m);
    a_thrust_z = (T_newton(1)-A_e(1)*p)*cosd(azimuth_rot)/(1000*m);
elseif 191.34<=t && t<195 % if coasting and decoupling
    a_thrust_x = 0;
    a_thrust_y = 0;
    a_thrust_z = 0;
elseif 195<=t && t<605 % if second stage
    a_thrust_x = (T_newton(2)-A_e(2)*p)*sind(beta)*sind(azimuth_rot)/(1000*m);
    a_thrust_y = (T_newton(2)-A_e(2)*p)*cosd(beta)*sind(azimuth_rot)/(1000*m);
    a_thrust_z = (T_newton(2)-A_e(2)*p)*cosd(azimuth_rot)/(1000*m);
elseif 605<=t % if orbital flight
    a_thrust_x = 0; 
    a_thrust_y = 0;
    a_thrust_z = 0;
else
    a_thrust_x = 0;
    a_thrust_y = 0;
    a_thrust_z = 0;
end

%% Gravity component
a_gravity_x = gx; % no need to divide by 1000 because already km/s^2
a_gravity_y = gy;
a_gravity_z = gz;


%% Initialize acceleration components
a_forces_x = a_gravity_x+a_thrust_x+a_drag_x;
a_forces_y = a_gravity_y+a_thrust_y+a_drag_y;
a_forces_z = a_gravity_z+a_thrust_z+a_drag_z;


%% Initialize mass flow rate
% TO BE IMPLEMENTED - ADDITIONAL M-FILE FOR VARIOUS FUELS|dm=function(choice)
if t<191.34
    dm = -205.5921053;
elseif t>=195 && t<605
    dm = -9.846153846;
else
    dm = 0;
end

%% Initialize differential equation
dydt = [dx, dy, dz, a_forces_x, a_forces_y, a_forces_z, dm]';
end